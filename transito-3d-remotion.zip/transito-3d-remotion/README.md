# Trânsito 3D — Remotion

Projeto inicial de vídeo vertical educativo em estilo 3D minimalista.

## Executar

```bash
npm install
npm run dev
```

## Renderizar MP4 pelo terminal

```bash
npm run build
```

O arquivo será salvo em `out/transito-3d.mp4`.

## Composição

- ID: `Transito3D`
- 1080 x 1920 (9:16)
- 30 FPS
- 30 segundos
- Cenário de estrada, carros estilizados, textos animados e quatro blocos de conteúdo.

## Personalizar

Edite `src/TrafficVideo.tsx`. Os textos de cada bloco estão nos arrays `headings` e `captions`.

Este é um protótipo visual: a explicação jurídica, a narração e a sincronização final precisam ser revisadas antes de publicar.
