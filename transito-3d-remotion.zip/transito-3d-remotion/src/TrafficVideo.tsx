import React from 'react';
import {
  AbsoluteFill,
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';

const lime = '#B9FF35';
const white = '#F4F5F7';
const muted = '#9BA2AE';

const Car: React.FC<{ x: number; y: number; scale?: number; color: string; rotate?: number }> = ({
  x, y, scale = 1, color, rotate = 0,
}) => (
  <g transform={`translate(${x} ${y}) scale(${scale}) rotate(${rotate})`}>
    <ellipse cx="0" cy="52" rx="65" ry="23" fill="#05070B" opacity=".42" />
    <path d="M-64 4 L-51 -25 Q-45 -36 -28 -38 L28 -38 Q46 -35 54 -20 L65 5 L65 38 Q62 48 48 48 L-48 48 Q-64 46 -64 32 Z" fill={color} stroke="#11151D" strokeWidth="5" />
    <path d="M-42 -24 Q-36 -32 -24 -32 L24 -32 Q37 -30 44 -17 L51 0 L-49 0 Z" fill="#18202A" />
    <path d="M-35 -25 L-22 -29 L-3 -29 L-3 -3 L-46 -3 Z" fill="#B9D4E4" opacity=".85" />
    <path d="M4 -29 L23 -28 Q33 -26 39 -16 L46 -3 L4 -3 Z" fill="#B9D4E4" opacity=".8" />
    <path d="M-58 12 L-48 12 L-48 24 L-60 24 Z M48 12 L59 12 L59 24 L48 24 Z" fill="#11151D" />
    <path d="M-43 39 L43 39" stroke="#D8E0E8" strokeWidth="4" opacity=".65" />
    <rect x="-49" y="-4" width="98" height="9" rx="4" fill={color} />
  </g>
);

const Road: React.FC<{ frame: number }> = ({ frame }) => {
  const dashOffset = (frame * 7) % 150;
  return (
    <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
      <defs>
        <linearGradient id="asphalt" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#353941" />
          <stop offset="1" stopColor="#171A20" />
        </linearGradient>
        <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#17231D" />
          <stop offset="1" stopColor="#080D0C" />
        </linearGradient>
        <filter id="glow"><feGaussianBlur stdDeviation="8" /></filter>
      </defs>
      <rect width="1080" height="1920" fill="url(#ground)" />
      {Array.from({ length: 13 }).map((_, i) => (
        <g key={i} opacity=".45">
          <path d={`M${40 + i * 91} ${100 + (i % 4) * 80} l42 -110 l42 110 z`} fill="#183A2B" />
          <path d={`M${65 + i * 91} ${100 + (i % 4) * 80} l17 -65 l17 65 z`} fill="#20503A" opacity=".55" />
        </g>
      ))}
      <path d="M-330 0 L1410 0 L1910 1920 L-830 1920 Z" fill="url(#asphalt)" stroke="#B7BCC5" strokeWidth="7" />
      <path d="M-260 0 L-220 0 L315 1920 L270 1920 Z" fill="#F4D35E" opacity=".95" />
      <path d="M1290 0 L1330 0 L850 1920 L810 1920 Z" fill="#E8EDF3" opacity=".9" />
      <path d="M530 0 L560 0 L620 1920 L590 1920 Z" fill="#F6F7F9" opacity=".85" />
      {Array.from({ length: 12 }).map((_, i) => {
        const y = ((i * 180 + dashOffset) % 2100) - 120;
        const w = 8 + y * 0.018;
        const x = 545 + y * 0.07;
        return <path key={i} d={`M${x} ${y} l${w} 0 l${w * 1.5} 95 l-${w} 0 z`} fill="#F7F8FA" opacity=".95" />;
      })}
    </svg>
  );
};

const Panel: React.FC<{ title: string; subtitle: string; frame: number }> = ({ title, subtitle, frame }) => {
  const { fps } = useVideoConfig();
  const enter = spring({ frame: frame - 5, fps, config: { damping: 18, stiffness: 110 } });
  return (
    <div style={{
      position: 'absolute', top: 250, left: 62, right: 62, padding: '34px 34px 38px',
      borderRadius: 28, background: 'rgba(8,11,17,.94)', border: '2px solid #303743',
      boxShadow: '0 24px 65px rgba(0,0,0,.35)', transform: `translateY(${(1-enter)*45}px)`, opacity: enter,
    }}>
      <div style={{ fontSize: 21, letterSpacing: 5, color: muted, fontWeight: 700, marginBottom: 24 }}>CÓDIGO DE TRÂNSITO · APRENDA</div>
      <div style={{ fontSize: 43, color: white, lineHeight: 1.12, fontWeight: 800 }}>{title}</div>
      <div style={{ fontSize: 48, color: lime, lineHeight: 1.15, fontWeight: 900, marginTop: 18 }}>{subtitle}</div>
    </div>
  );
};

const BottomCaption: React.FC<{ text: string; frame: number }> = ({ text, frame }) => {
  const { fps } = useVideoConfig();
  const pop = spring({ frame, fps, config: { damping: 12, stiffness: 160 } });
  return (
    <div style={{ position: 'absolute', bottom: 245, width: '100%', display: 'flex', justifyContent: 'center', opacity: pop, transform: `scale(${0.85 + pop * 0.15})` }}>
      <div style={{ background: '#080D16', padding: '20px 30px', borderRadius: 20, fontSize: 43, fontWeight: 900, color: white, boxShadow: '0 12px 35px #0008' }}>{text}</div>
    </div>
  );
};

export const TrafficVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const scene = Math.floor(frame / 225);
  const local = frame % 225;
  const carX = interpolate(frame, [0, 899], [850, 600], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const greenX = interpolate(frame, [0, 899], [1040, 820], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const pulse = 0.5 + Math.sin(frame / 12) * 0.5;
  const headings = [
    ['DUAS SITUAÇÕES QUE PARECEM IGUAIS', 'ULTRAPASSAR NÃO É O MESMO QUE PASSAR'],
    ['PRIMEIRO, ENTENDA A DIFERENÇA', 'ULTRAPASSAR: SAIR, PASSAR E VOLTAR'],
    ['OBSERVE O MOVIMENTO DOS CARROS', 'A MANOBRA PRECISA SER SEGURA'],
    ['CONHECER A REGRA FAZ DIFERENÇA', 'DIRIJA COM ATENÇÃO!'],
  ];
  const captions = ['Você sabe a diferença?', 'Ultrapassar é sair da faixa...', 'Passar é seguir sem essa manobra.', 'Respeite a sinalização!'];
  const title = headings[scene][0];
  const subtitle = headings[scene][1];
  const caption = captions[scene];
  const fade = interpolate(local, [0, 18, 207, 225], [0, 1, 1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const carScale = interpolate(frame, [0, 899], [0.76, 1.08]);

  return (
    <AbsoluteFill style={{ backgroundColor: '#080B10', fontFamily: 'Arial, Helvetica, sans-serif', overflow: 'hidden' }}>
      <Road frame={frame} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(0,0,0,.28),transparent 38%,rgba(0,0,0,.25))' }} />
      <div style={{ position: 'absolute', top: 90, left: 55, color: '#D5D9E0', letterSpacing: 7, fontSize: 22, fontWeight: 700 }}>MUNDO CURIOSO · PELA DIREITA</div>
      <div style={{ position: 'absolute', top: 145, left: 55, borderRadius: 40, padding: '12px 26px', background: '#111923', border: '2px solid #68717E', color: white, fontSize: 27, fontWeight: 900, letterSpacing: 3 }}><span style={{ color: lime }}>●</span> A LEI</div>
      <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
        <Car x={carX} y={940 + Math.sin(frame / 24) * 7} scale={carScale} color="#E9EDF2" rotate={-5} />
        <Car x={greenX} y={1240 + Math.sin(frame / 27) * 8} scale={1.15} color={lime} rotate={-5} />
      </svg>
      <div style={{ opacity: fade }}><Panel title={title} subtitle={subtitle} frame={local} /></div>
      <BottomCaption text={caption} frame={local} />
      <div style={{ position: 'absolute', bottom: 105, left: 60, right: 60, display: 'flex', justifyContent: 'space-between', color: '#AEB5C0', fontSize: 20, letterSpacing: 2 }}>
        <span>EDUCAÇÃO NO TRÂNSITO</span><span style={{ color: lime }}>● {Math.round((frame / 899) * 100)}%</span>
      </div>
      <div style={{ position: 'absolute', top: 0, left: 0, height: 8, width: `${(frame / 899) * 100}%`, background: lime, boxShadow: `0 0 ${10 + pulse * 10}px ${lime}` }} />
    </AbsoluteFill>
  );
};
