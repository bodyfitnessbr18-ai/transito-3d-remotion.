import React from 'react';
import { Composition } from 'remotion';
import { TrafficVideo } from './TrafficVideo';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="Transito3D"
      component={TrafficVideo}
      durationInFrames={900}
      fps={30}
      width={1080}
      height={1920}
    />
  </>
);
